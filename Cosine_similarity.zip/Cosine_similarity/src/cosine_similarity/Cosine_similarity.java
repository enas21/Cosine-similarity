/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cosine_similarity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.*;

/**
 *
 * @author Enas
 */
class Index{
    String name;
    String name_2;
    double value;
    Index(String name ,String name_2 ,double value){
        this.name = name;
        this.name_2 = name_2;
        this.value = value;
    }
}
public class Cosine_similarity {

        private ArrayList<String> readFile(String fileName) throws Exception {
        BufferedReader file = new BufferedReader(new FileReader(fileName));
        String line;
        ArrayList<String> wordsSet = new ArrayList<>();
        while ((line = file.readLine()) != null) {
            String[] words = line.split("\\W+"); // split by any special char like ! or space or @ //to get every word of the line
            for (String word : words) {
                word = word.toLowerCase();
                wordsSet.add(word);
            }
        }
        return wordsSet;
    }
        private HashSet<String> union(ArrayList<String>file_1,ArrayList<String> file_2){
        HashSet<String>file_1_Clone = new HashSet<String>(file_1);
        ArrayList<String>file_2_Clone = new ArrayList<String>(file_2);
        file_1_Clone.addAll(file_2_Clone);
        return file_1_Clone;
    }
        private HashSet<String> intersect(ArrayList<String> query, ArrayList<String> fileWords) {
            HashSet<String>queryClone = new HashSet<String>(query);
            HashSet<String>fileWordsClone = new HashSet<String>(fileWords);

        if (queryClone.size()<=fileWordsClone.size()){

                HashSet<String> newQuery = new HashSet<>(queryClone);
                newQuery.removeAll(fileWordsClone);
                queryClone.removeAll(newQuery);
                return queryClone;
            }else{

                HashSet<String> newQuery = new HashSet<>(fileWordsClone);
                newQuery.removeAll(queryClone);
                fileWordsClone.removeAll(newQuery);
                return fileWordsClone;
            }

    }

        public int[] docTable(ArrayList<String> doc, HashSet<String> union) {
         int[] result = new int[union.size()];
         String[] arr_1 = doc.toArray(new String[union.size()]);
         String[] arr_2 = union.toArray(new String[union.size()]);
          for (int i =0 ;i < arr_2.length;i++){
              for (int j =0 ;j < arr_2.length;j++){
                if(arr_1[i]==null)
                {
                    continue;
                }
                if(arr_1[i].equalsIgnoreCase(arr_2[j]))
                {
                    result[j]++;
                }

           }
          }
                  return result ;
        }
        
        public double cosinSimilarity(String file_1 , String file_2)throws Exception {
            
            ArrayList<String>  wordSet_1 = readFile(file_1);
            ArrayList<String>  wordSet_2 = readFile(file_2);
            HashSet<String> unionValue = union(wordSet_1,wordSet_2);
            HashSet<String> intersectValue = intersect(wordSet_1,wordSet_2);
            //System.out.println("intersect = : "+ intersectValue);
            int doc_1[] = docTable(wordSet_1,unionValue);
            int doc_2[] = docTable(wordSet_2,unionValue);
        double dotProduct = 0.0;
        double normA = 0.0;
        double normB = 0.0;
        for (int i = 0; i < unionValue.size(); i++) {
        dotProduct += doc_1[i] * doc_2[i];
        normA += Math.pow(doc_1[i], 2);
        normB += Math.pow(doc_2[i], 2);
        }   
        double cos = dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
        //System.out.println("Cosine = "+cos);
        double ans = Math.acos(cos);
        double in_degrees = Math.toDegrees(ans);
        return  in_degrees;  
        }
        
        
     static void sort(ArrayList<Index> arr) {


        // One by one move boundary of unsorted subarray
        for (int i = 0; i < arr.size(); i++)
        {
            // Find the minimum element in unsorted array
            int min_idx = i;
            for (int j = i+1; j < arr.size(); j++)
                if (arr.get(j).value > arr.get(min_idx).value)
                    min_idx = j;

            // Swap the found minimum element with the first
            // element
            Index temp = arr.get(min_idx);
            arr.set(min_idx,arr.get(i)) ;
            arr.set(i,temp) ;
        }
    }
        
    public static void main(String[] args) {
        Cosine_similarity cosine_similarity = new Cosine_similarity();
        try{
            File directoryPath = new File("F:\\Projects\\Information Retrieval\\docs");
            File files[] = directoryPath.listFiles();
            String filesNames[] = new String[files.length];
            int i =0;
            for(File file : files) {
              filesNames[i] = directoryPath +"\\"+ file.getName();
              System.out.println("File name: "+filesNames[i]);
              i=i+1;
               }
            ArrayList<Index>values = new ArrayList<>();
            double val;
            for(int j =0 ; j<4;j++)
            {
                for(int k=0 ;k<5;k++)
                {
                    if(filesNames[j].equalsIgnoreCase(filesNames[k])){
                        continue;
                    }
                    if(k>j)
                    {
                        continue;
                    }
                    val = cosine_similarity.cosinSimilarity(filesNames[j], filesNames[k]);
                    Index index = new Index(filesNames[j],filesNames[k],val);
                    values.add(index);
                }
            }
            sort(values);
            for (Index index : values) {
            System.out.println("Doc "+index.name+"  And Doc "+index.name_2+"  Cosine Similarity = "+ index.value);
            }
    }
        catch (Exception error){

            System.out.println(error.getMessage());
        }
}
}

